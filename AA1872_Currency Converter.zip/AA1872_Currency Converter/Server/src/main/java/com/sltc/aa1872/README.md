Host Address:

http://localhost:8888/CurrencyConversionWebServiceAA1872?wsdl