# Curreny-Converter
 Assignment 02 of the Module CCS310: Software Architecture.
 <br>
 This Currency Conveter was developed using HTML, Python and Java.
 
